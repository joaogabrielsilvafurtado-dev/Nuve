import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = process.env.PORT || 3000;
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-6-astra";
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "30kb" }));
app.use(express.static(__dirname));

app.post("/api/generate-site", async (req, res) => {
  try {
    if (!apiKey) {
      return res.status(503).json({ error: "Servidor sem OPENAI_API_KEY configurada." });
    }
    const prompt = String(req.body?.prompt || "").trim();
    if (!prompt || prompt.length > 4000) {
      return res.status(400).json({ error: "Descreva o site (até 4.000 caracteres)." });
    }

    const client = new OpenAI({ apiKey });
    const result = await client.responses.create({
      model,
      instructions: `Você é o gerador de sites da Vex AI. Retorne SOMENTE um documento HTML completo, válido e autônomo, sem Markdown e sem explicações fora do código. Crie um site responsivo, acessível, mobile-first, com CSS dentro de <style>, sem bibliotecas externas obrigatórias. Use textos em português do Brasil. Não invente telefone, endereço, avaliações ou dados reais: quando faltarem, use campos claramente marcados para personalização. Não inclua scripts de terceiros, coleta de dados, checkout falso nem promessas enganosas. O site deve ser visualmente profissional e adequado à descrição do cliente.`,
      input: prompt,
      max_output_tokens: 12000
    });

    let html = (result.output_text || "").trim();
    html = html.replace(/^```(?:html)?\s*/i, "").replace(/\s*```$/, "");
    if (!/^<!doctype html|^<html/i.test(html)) {
      return res.status(502).json({ error: "A IA não retornou um HTML válido. Tente descrever o site de outra forma." });
    }
    const filename = "site-vex-ai.html";
    res.json({ html, filename });
  } catch (error) {
    console.error("Erro na geração:", error?.status || error?.message || "erro desconhecido");
    res.status(500).json({ error: "Falha ao gerar o site. Confira a chave, o modelo e os créditos da API." });
  }
});

app.listen(port, () => console.log(`Vex AI disponível na porta ${port}`));
